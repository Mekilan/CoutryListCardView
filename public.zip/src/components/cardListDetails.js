import React, { Component } from 'react';

class cardListDetails extends Component {
    constructor(props) {
        super(props);

    }

    onClose = () => {
        this.props.callback(false);
    }
    render() {
        return (
            <div className="modal" tabIndex="-1" role="dialog" style={{ display: this.props.modalopen ? 'block' : 'none' }}>
                <div className="modal-dialog" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <div className="img-card">
                                <img src={this.props.detaillist.flag} className="card-img-top" alt={this.props.detaillist.name} /></div>
                            <h5 className="modal-title">{this.props.detaillist.name}</h5>
                            <button type="button" className="close modal-close" data-dismiss="modal" aria-label="Close" onClick={this.onClose}>
                                <span aria-hidden="true" className="modal-span-times">&times;</span>
                            </button>
                        </div>
                        <div className="modal-body">
                            <ul>
                                <li>
                                    <span>AlphaCode: {this.props.detaillist.alpha2Code}</span>
                                </li>
                            </ul>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" data-dismiss="modal" onClick={this.onClose}>Close</button>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default cardListDetails;
